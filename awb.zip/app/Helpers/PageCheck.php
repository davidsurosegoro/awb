<?php

    function ceks()
    {
    	return true;
    }